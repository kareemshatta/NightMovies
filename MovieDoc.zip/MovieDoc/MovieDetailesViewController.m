//
//  MovieDetailesViewController.m
//  MovieDoc
//
//  Created by kareem shatta on 9/4/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import "MovieDetailesViewController.h"


@interface MovieDetailesViewController ()
{

    NSString *year,*time, *i;
    NSDictionary *movieTrailerDic, *movieTimeDic, *movieReviewDic;
    NSMutableArray *trailersKeys , *reviewsData ,*reviewAuthor;
    YTViewController *ytPlayer;
    
    
}
@end

@implementation MovieDetailesViewController

static NSString * const reuseIdentifier = @"cell2";

    
- (void)viewDidLoad {
    [super viewDidLoad];
    trailersKeys = [NSMutableArray new];
    reviewsData = [NSMutableArray new];
    reviewAuthor = [NSMutableArray new];
    NSLog(@"asdaaaaaaaaaaaaaaa");
    
    NSString *docsDir;
    NSArray *dirPaths;
    dirPaths = NSSearchPathForDirectoriesInDomains(	NSDocumentDirectory, NSUserDomainMask, YES);
    
    docsDir = dirPaths[0];
    
    _databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent: @"movies.db"]];
    const char *dbPath = [_databasePath UTF8String];
    
    if (sqlite3_open(dbPath,&_moviesDB) == SQLITE_OK) {
        char *errMsg;
        const char *sql_stmt =
        "CREATE TABLE IF NOT EXISTS MOVIES (ID INTEGER PRIMARY KEY, NAME TEXT, IMAGEPATH TEXT, OVERVIEW TEXT, DATE TEXT, TIME TEXT, RATE TEXT);";
        
        if (sqlite3_exec(_moviesDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
        {
            NSLog(@"Failed to create table");
        }else{
            NSLog(@"create table");
        }
        sqlite3_close(_moviesDB);
        
    }else{
        NSLog(@"cannot create/open database");
    }
    
    
    
    
    //ToDo hide navigation bar
//    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
//    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
//    self.navigationController.navigationBar.translucent = YES;
//    self.navigationController.view.backgroundColor = [UIColor clearColor];
    
    
    
    //URLs
    NSString *timeUrl =@"http://api.themoviedb.org/3/movie/";
    NSString *baseUrl = [NSString stringWithFormat:@"http://api.themoviedb.org/3/movie/%@",[_movie i]];
    NSDictionary *parameters=@{@"api_key":@"52d66cf2b0be75da4100e52b0a3756f1"};
   
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[[NSURL alloc] initWithString:baseUrl]];
    [manager GET:@"videos" parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        movieTrailerDic = responseObject;
        //get "key" , "name"
        for(int i = 0; i<[[movieTrailerDic objectForKey:@"results"] count] ; i++){
            [trailersKeys addObject:[[movieTrailerDic objectForKey:@"results"][i] objectForKey:@"key"]];
        }
        self.collectionTrail.reloadData;
        [_movie setTrailerKeys:trailersKeys];

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"errror  %@",error);
    }];
    
    
    // getting reviews
    
    manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[[NSURL alloc] initWithString:baseUrl]];
    [manager GET:@"reviews" parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //NSLog(@"/n Reviews success : \n %@",responseObject);
        movieReviewDic = responseObject;
        //get "author" , "content"
        for(int i = 0; i<[[movieReviewDic objectForKey:@"results"] count] ; i++){
            [reviewAuthor addObject:[[movieReviewDic objectForKey:@"results"][i] objectForKey:@"author"]];
            [reviewsData addObject:[[movieReviewDic objectForKey:@"results"][i] objectForKey:@"content"]];
        }
        [_movie setReviewAuthor:reviewAuthor];
        [_movie setReviewContent:reviewsData];
        self.collectionReviews.reloadData;
        
        if ([reviewAuthor count] == 0) {
            [_authorReview setText:@"No Reviews For This Movie ..."];
        }else{
            [_authorReview setText:@"Please Choose Person To Show Its Review ..."];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    }];
    
    // getting movie runtime
    
    manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[[NSURL alloc] initWithString:timeUrl]];
    [manager GET:[NSString stringWithFormat:@"%@",[_movie i]] parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        movieTimeDic = responseObject;
        [_movie setRunTime:[NSString stringWithFormat:@"%@ Min",[movieTimeDic objectForKey:@"runtime"]]];
        [_movieTime setText:[_movie runTime]];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    }];
    
    
    
    
    //set movie data
    
    [_movieOverview setText:[_movie overview]];
    year=[[_movie releaseDate]  substringToIndex:4];
    [_movieYear setText:year];
    
    [_movieRate setText: [NSString stringWithFormat:@"%.1f",[_movie voteAverage]]];
    NSURL *url = [[NSURL alloc] initWithString:[_movie imagePath]];
    [_movieImage sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    [_movieImageBG sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    
    
    
    
    
    
    
    //to get image from local key
//    SDImageCache *imageCache = [[SDImageCache alloc] init];
//    [imageCache queryCacheOperationForKey:_movie.localKey done:^(UIImage * _Nullable img, NSData * _Nullable data, SDImageCacheType cacheType) {
//            [_movieImage setImage:img];
//        }];
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
#warning Incomplete implementation, return the number of sections
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of items
    if(collectionView == _collectionTrail){
        return [trailersKeys count];
    }else{
        
        return [reviewAuthor count];
    }
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    if (collectionView == _collectionTrail) {
        UIImageView *image = [cell viewWithTag:5];
        [image setImage:[UIImage imageNamed:@"video-player.png"]];
    }else{
        UIImageView *image = [cell viewWithTag:4];
        [image setImage:[UIImage imageNamed:@"pc.png"]];
        
    }
    
    return cell;
}

#pragma mark <UICollectionViewDelegate>

/*
 // Uncomment this method to specify if the specified item should be highlighted during tracking
 - (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
 return YES;
 }
 */

/*
 // Uncomment this method to specify if the specified item should be selected
 - (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
 return YES;
 }
 */
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if(collectionView == _collectionTrail){
        ytPlayer = [self.storyboard instantiateViewControllerWithIdentifier:@"YTVC"];
        [ytPlayer setTrailKey:[trailersKeys objectAtIndex:indexPath.row]];
        [self.navigationController pushViewController:ytPlayer animated:YES];
        
    }else{
        [_movieAutor setText:[_movie reviewAuthor][indexPath.row]];
        //NSLog(@"-------- %d",indexPath.row);
        [_movieAutor setHidden:NO];
        [_authorReview setText:[_movie reviewContent][indexPath.row]];
    }
    
}
/*
 // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
 - (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
 return NO;
 }
 
 - (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
 return NO;
 }
 
 - (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
 
 }
 */

- (IBAction)favoriteAction:(id)sender {
    
    
    sqlite3_stmt *statement;
    const char *dbpath = [_databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &_moviesDB) == SQLITE_OK)
    {
        
        NSString *insertSQL = [NSString stringWithFormat:
                               @"INSERT INTO MOVIES (id, name, imagepath, overview, date, time, rate) VALUES (\"%@\", \"%@\", \"%@\",\"%@\", \"%@\", \"%@\", \"%@\")",
                               _movie.i, _movie.originalTitle, _movie.imagePath, _movie.overview, _movie.releaseDate, _movie.runTime, [NSString stringWithFormat:@"%f",_movie.voteAverage]];
        
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare(_moviesDB, insert_stmt,
                           -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE)
        {
            NSLog(@"movie added --------");
        } else {
            NSLog(@"movie added before --------");

            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warnning" message:@"This movie is already exist in favorite list." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            alert.backgroundColor = [UIColor darkGrayColor];
            [alert show];
        }
        sqlite3_finalize(statement);
        sqlite3_close(_moviesDB);
    }
    
    
    
    
}
@end
