//
//  YTViewController.h
//  MovieDoc
//
//  Created by kareem shatta on 9/9/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YTPlayerView.h"

@interface YTViewController : UIViewController
@property NSString *TrailKey;
@property (weak, nonatomic) IBOutlet YTPlayerView *playerView;

@end
