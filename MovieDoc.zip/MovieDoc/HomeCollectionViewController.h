//
//  HomeCollectionViewController.h
//  MovieDoc
//
//  Created by kareem shatta on 9/4/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import <AFHTTPSessionManager.h>
#import "MovieDetailesViewController.h"


@interface HomeCollectionViewController : UICollectionViewController <UITabBarDelegate>
- (IBAction)sortAction:(id)sender;
@property int xms;


@end
