//
//  MovieClass.m
//  MovieDoc
//
//  Created by kareem shatta on 9/6/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import "MovieClass.h"

@implementation MovieClass

@end
