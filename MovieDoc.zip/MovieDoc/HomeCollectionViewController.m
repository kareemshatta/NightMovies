//
//  HomeCollectionViewController.m
//  MovieDoc
//
//  Created by kareem shatta on 9/4/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import "HomeCollectionViewController.h"



@interface HomeCollectionViewController (){
    NSString *imgPath;
    NSDictionary *moviesDic;
    NSMutableArray *posters;
    MovieDetailesViewController *movieDetailsVC;
}

@end

@implementation HomeCollectionViewController
static int i = 0 ,numOfPage = 2;
static NSString * const reuseIdentifier = @"cell";


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //assign values to member data
    [self.navigationItem setTitle:@"Popular Movies"];
    posters = [NSMutableArray new];
    
    
    //////////////////////////////
    NSString *url = @"http://api.themoviedb.org/3/discover/movie?";
    NSDictionary *parameters =@{@"sort_by":@"popularity.desc" , @"api_key":@"52d66cf2b0be75da4100e52b0a3756f1"};
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
       // NSLog(@"success : \n %@",responseObject);
        moviesDic = responseObject;
        posters = [responseObject valueForKeyPath:@"results.poster_path"];
        _xms = 1;
        self.collectionView.reloadData;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
       
        
    }];
    
    
    
    
    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Register cell classes
    
//    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
//
    // Do any additional setup after loading the view.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
#warning Incomplete implementation, return the number of sections
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of items
    return [posters count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    imgPath = [NSString stringWithFormat:@"http://image.tmdb.org/t/p/w185%@",[posters objectAtIndex:indexPath.row]];
    
    UIImageView *image = [cell viewWithTag:1];
    
    [image sd_setImageWithURL:[NSURL URLWithString:imgPath]
                 placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    int numberOfCellInRow = 2;
    CGFloat cellWidth =  [[UIScreen mainScreen] bounds].size.width/numberOfCellInRow;
    CGFloat cellheight =  ([[UIScreen mainScreen] bounds].size.height/numberOfCellInRow)-55;
    return CGSizeMake(cellWidth, cellheight);
    
}

/*
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat bottomPage = scrollView.contentOffset.y + scrollView.frame.size.height;

    if (bottomPage == scrollView.contentSize.height +[[[self tabBarController] tabBar] bounds].size.height ) {
        if (_xms == 1) {
            NSString *url = [NSString stringWithFormat:@"http://api.themoviedb.org/3/discover/movie?api_key=52d66cf2b0be75da4100e52b0a3756f1&sort_by=popularity.desc" &language=en-US&page=%d",numOfPage];
            
            AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
            [manager GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                // NSLog(@"success : \n %@",responseObject);
                moviesDic = responseObject;
                NSArray *moo =[NSArray new];
             moo=   [responseObject valueForKeyPath:@"results.poster_path"];
              
            posters=    [posters arrayByAddingObjectsFromArray:moo];
                 NSLog(@"aaaaaaaa %@",posters);
                NSLog(@"kkkkkkkkkk---------");
                self.collectionView.reloadData;
                numOfPage++;
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            }];
            
        }
    }
    
}
*/

#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    movieDetailsVC = [self.storyboard instantiateViewControllerWithIdentifier:@"movieDetVC"];
    movieDetailsVC.movie = [MovieClass new];
    [movieDetailsVC.movie setI: [[moviesDic objectForKey:@"results"][indexPath.row] objectForKey:@"id"]];
    [movieDetailsVC.movie setOriginalTitle: [[moviesDic objectForKey:@"results"][indexPath.row] objectForKey:@"original_title"]];
    
    [movieDetailsVC.movie setOverview: [[moviesDic objectForKey:@"results"][indexPath.row] objectForKey:@"overview"]];
    imgPath = [NSString stringWithFormat:@"http://image.tmdb.org/t/p/w185%@",[[moviesDic objectForKey:@"results"][indexPath.row] objectForKey:@"poster_path"]];
    [movieDetailsVC.movie setImagePath:imgPath];
  NSNumber *nn =  [[moviesDic objectForKey:@"results"][indexPath.row] objectForKey:@"vote_average"];
    [movieDetailsVC.movie setVoteAverage:[nn doubleValue]];
    
    [movieDetailsVC.movie setReleaseDate: [[moviesDic objectForKey:@"results"][indexPath.row] objectForKey:@"release_date"]];
    
    [self.navigationController pushViewController:movieDetailsVC animated:YES];
    
}
/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

- (IBAction)sortAction:(id)sender {
    
    if (i == 0) {
        //assign values to member data
        [self.navigationItem setTitle:@"Top Rated Movies "];
        /////////////////////////////
        NSString *url = @"http://api.themoviedb.org/3/movie/top_rated?";
        NSDictionary *parameters =@{@"api_key":@"52d66cf2b0be75da4100e52b0a3756f1"};
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        [manager GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //NSLog(@"success : \n %@",responseObject);
            moviesDic = responseObject;
            posters = [responseObject valueForKeyPath:@"results.poster_path"];
            self.collectionView.reloadData;
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            
        }];
        self.collectionView.reloadData;
        i = 1;
        
    }else{
        //assign values to member data
        [self.navigationItem setTitle:@"Popular Movies "];
        //////////////////////////////
        NSString *url = @"http://api.themoviedb.org/3/discover/movie?";
        NSDictionary *parameters =@{@"sort_by":@"popularity.desc" , @"api_key":@"52d66cf2b0be75da4100e52b0a3756f1"};
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        [manager GET:url parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //NSLog(@"success : \n %@",responseObject);
            moviesDic = responseObject;
            posters = [responseObject valueForKeyPath:@"results.poster_path"];
            self.collectionView.reloadData;
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
        }];
        self.collectionView.reloadData;
        i = 0;
    }
    
}

@end
