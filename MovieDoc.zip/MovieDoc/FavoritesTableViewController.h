//
//  FavoritesTableViewController.h
//  MovieDoc
//
//  Created by kareem shatta on 9/4/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "MovieClass.h"
#import "MovieDetailesViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface FavoritesTableViewController : UITableViewController<UITabBarDelegate>
@property (strong, nonatomic) IBOutlet UITableView *favtable;
//database

@property (strong,nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *moviesDB;

@end
