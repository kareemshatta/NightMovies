//
//  MovieClass.h
//  MovieDoc
//
//  Created by kareem shatta on 9/6/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieClass : NSObject
@property NSString *i,
*originalTitle,
*imagePath,
*overview,
*releaseDate,
*runTime,
*state;

@property double voteAverage;

@property NSMutableArray *trailerKeys , *reviewAuthor , *reviewContent;

@end
