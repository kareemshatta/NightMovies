//
//  MovieDetailesViewController.h
//  MovieDoc
//
//  Created by kareem shatta on 9/4/18.
//  Copyright © 2018 kareem shatta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieClass.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <AFHTTPSessionManager.h>
#import "YTViewController.h"
#import "FavoritesTableViewController.h"
#import <sqlite3.h>

@interface MovieDetailesViewController : UIViewController <UITableViewDataSource , UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UITextView *authorReview;
@property (weak, nonatomic) IBOutlet UILabel *movieAutor;
@property (weak, nonatomic) IBOutlet UIScrollView *movieDetScroll;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionReviews;

@property (weak, nonatomic) IBOutlet UIButton *starBtn;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionTrail;

@property MovieClass *movie;
@property (weak, nonatomic) IBOutlet UIImageView *movieImageBG;
@property (weak, nonatomic) IBOutlet UIImageView *movieImage;
@property (weak, nonatomic) IBOutlet UILabel *movieYear;

@property (weak, nonatomic) IBOutlet UILabel *movieRate;
@property (weak, nonatomic) IBOutlet UILabel *movieTime;
@property (weak, nonatomic) IBOutlet UITextView *movieOverview;

//database

@property (strong,nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *moviesDB;

- (IBAction)favoriteAction:(id)sender;

@end
